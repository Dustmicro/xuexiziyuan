#include<iostream>
#include<cstdlib>
#include<string.h>
#include"stu.h"
//#include "date.h"
using namespace std;
/* run this program using the console pauser or add your own getch, system("pause") or input loop */


int main(int argc, char** argv) {

	CSTU sTemp(1);
	sTemp.showMenu();
	return 0;
	} 
